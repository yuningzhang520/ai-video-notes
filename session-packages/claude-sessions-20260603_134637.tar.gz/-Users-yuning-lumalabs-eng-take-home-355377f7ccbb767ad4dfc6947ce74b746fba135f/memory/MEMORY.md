# Memory Index

- [Commit review discipline](commit-review-discipline.md) — review gate + explicit approval before every commit; stage by name, never `git add -A`.
- [Build step workflow](build-step-workflow.md) — one PLAN.md step per turn, tightly scoped; honest docs; verify trust moment before reporting.
- [Tesseract sandbox TMPDIR](tesseract-sandbox-tmpdir.md) — pytesseract fails in the Bash sandbox unless `TMPDIR="$(pwd)/work/tmp"`.
