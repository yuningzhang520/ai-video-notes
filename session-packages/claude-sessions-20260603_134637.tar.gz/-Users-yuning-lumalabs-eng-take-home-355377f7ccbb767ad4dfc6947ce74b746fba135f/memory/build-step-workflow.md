---
name: build-step-workflow
description: "How this Video->Visual-Notes build is driven — one PLAN.md step per turn, tightly scoped"
metadata: 
  node_type: memory
  type: project
  originSessionId: 53ae7a79-b131-4596-95f9-1fa682fd9af1
---

The user drives this build strictly one PLAN.md step at a time. Each turn they say e.g. "Start Step N only … do not start Step N+1", restate the scope guardrails (no yt-dlp/ffmpeg/OCR/Anthropic/pipeline/queue/persistence/React until the step that introduces them), and expect tight, surgical changes that do not redesign earlier steps.

Recurring expectations:
- **Honest docs:** keep APPROACH.md and PLAN.md truthful to what actually shipped (e.g. corrected "real frames" -> "stable placeholder frames"; don't imply extraction/vision happened before it does).
- **Verify before reporting:** run pytest AND a browser-level check of the trust moment. Docker isn't installed locally, so container behavior is verified by running the exact `CMD` shell line; browser behavior is verified with a throwaway jsdom harness in /tmp that runs the real `static/app.js` against the live uvicorn server, stubbing only YouTube's `YT.Player` to capture `seekTo` calls.
- **Don't-mark-done gate:** a step that needs external verification (e.g. 1B's public URL) stays in-progress in PLAN.md until the user confirms.
- **Report shape:** files changed, run command, endpoints, exactly what was verified, next step.

Progress so far: 1A (fixture skeleton), 1B (Docker + /healthz + deploy, live at https://luma-video-notes.onrender.com), 2 (claim-level grounding) are committed. Next is Step 3 (first real frame + one vision call; adds yt-dlp/ffmpeg to the Dockerfile). See [[commit-review-discipline]] for the commit gate.
