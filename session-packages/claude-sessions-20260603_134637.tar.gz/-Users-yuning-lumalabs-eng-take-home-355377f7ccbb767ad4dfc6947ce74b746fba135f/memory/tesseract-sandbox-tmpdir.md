---
name: tesseract-sandbox-tmpdir
description: pytesseract fails in the Claude Code Bash sandbox unless TMPDIR points into the repo
metadata: 
  node_type: memory
  type: reference
  originSessionId: 15f1ac50-f639-4900-a82e-e9fe378423f9
---

Running `scripts/analyze_demo_frames.py` (or any pytesseract call) inside the Claude Code
Bash sandbox fails with a cryptic `UnicodeDecodeError` / Leptonica "image file not found".
Cause: pytesseract round-trips the image through `$TMPDIR` (`/tmp/claude-501/...`), which the
Homebrew `tesseract` child process cannot read. Fix: prefix the command with
`TMPDIR="$(pwd)/work/tmp"` (a repo-local, gitignored dir). The committed code is deliberately
left clean — this is ONLY a sandbox artifact; on a normal macOS shell / in Docker, `$TMPDIR`
is fine and pytesseract works unmodified. Tesseract binary: `brew install tesseract`.
Relates to [[build-step-workflow]] (Step 4A frame selection).
