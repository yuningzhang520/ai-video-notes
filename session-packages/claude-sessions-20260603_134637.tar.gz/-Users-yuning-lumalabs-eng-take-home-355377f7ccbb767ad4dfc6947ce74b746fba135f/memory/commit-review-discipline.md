---
name: commit-review-discipline
description: How the user wants commits handled in this repo — review gate before every commit
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 53ae7a79-b131-4596-95f9-1fa682fd9af1
---

Before EVERY `git commit` in this repo, the user wants a review gate and explicit approval:
- print `git status --short` and `git diff --cached --name-only`
- confirm `.env`, `.take-home-token`, `submit.sh`, and anything under `dist/` are NOT staged
- stage explicitly by name — never `git add -A`
- then STOP and wait for approval; commit only after the user says so, using the exact commit message they provide

**Why:** this is a take-home repo with secrets/tokens and a `submit.sh` that wipes `dist/`; the user is deliberate about what enters history and reviews each staged set. They have enforced this on every commit so far.

**How to apply:** treat committing as a separate, approval-gated step. Do the work, verify it, stage by name, present the review output, and wait. Append the required `Co-Authored-By: Claude Opus 4.8 (1M context)` trailer to the user's exact message. Commit directly to `main` (repo convention; see [[build-step-workflow]]).
