export const meta = {
  name: 'plan-5a-bullets',
  description: 'Audit every file Step 5A (bullets data model) touches + red-team the design, to produce a precise implementation plan',
  phases: [{ title: 'Audit', detail: 'parallel area owners return current-state + required-changes + breakage + risks' }],
}

// The target design for 5A (DATA ONLY — no app.js/CSS), locked by the user.
const DESIGN = `
STEP 5A TARGET DESIGN (DATA ONLY — do NOT touch rendering app.js/CSS; that is 5B. Reuse
committed 4A/4B artifacts: frame_analysis.json + visual_blocks.json — do NOT re-run vision;
only the structure pass re-runs with --force).

SCHEMA CHANGE:
- New nested model Bullet { text, anchor?, blocks: VisualBlock[] }.
- Section becomes { id, title, gist, bullets: Bullet[] }. DROP the 'detail' field entirely.
  The section-level 'anchors' and 'visualBlocks' lists are REPLACED by per-bullet anchor +
  per-bullet blocks[].

BULLETS:
- The structure pass produces bullets DIRECTLY as the primary content (no detail paragraph
  as an intermediate; bullets are not split from prose). Each bullet is one complete
  proposition (claim + mechanism/example/why), NOT a headline fragment. ~1-7 bullets/section,
  segmented by the topic's own logic (no fixed template); 1 only if genuinely a single point.

THREE GROUNDING TIERS, per bullet, all click->seek->play (player behavior identical):
- visual bullet  -> grounded by an associated block/frame (uses the block's
  suggestedVerifyTimestampSec from frame_analysis as the verify-lead).
- spoken bullet  -> grounded by a TRANSCRIPT timestamp + the transcript text of that span,
  NO frame. This transcript-span grounding tier is NEW and must be represented in the data
  and accepted as grounded with EQUAL status to a frame-backed anchor.
- genuinely ungrounded -> no source; keep Step 2 shown-but-not-clickable behavior.

TIMESTAMPS (LLM never invents them):
- spoken bullet: the plan CITES a transcript segment; assembly deterministically SNAPS to the
  nearest real segment.start (same discipline as the verify-lead).
- visual bullet: keep the block's suggestedVerifyTimestampSec.

BLOCK -> BULLET ASSOCIATION (blocks already exist from 4B; structure pass MATCHES, never mints):
- one block attaches to AT MOST ONE bullet (its single most-relevant; never repeats).
- a bullet may carry 0, 1, or MULTIPLE blocks.
- matching: time proximity (block.timestampSec) narrows candidates, content relevance picks one.
- a valuable block with no relevant spoken bullet -> becomes its OWN visual bullet (short text).
- SEMANTIC FILTER (structure pass responsibility): junk blocks (e.g. raw JSON/debug dump that
  passed 4A's char-count gate) -> left UNPLACED (not attached, not a visual bullet) and REPORTED.

INVARIANTS: block CONTENT stays verbatim (bullet text is model-generated; block content is
NOT — never let the model rewrite/fold block content into bullet text); re-prompt stays
structure-only; verify-lead preserved; the genuinely-ungrounded tier survives.
`

const AUDIT = {
  type: 'object',
  required: ['area', 'currentState', 'requiredChanges', 'breakage', 'risks'],
  additionalProperties: false,
  properties: {
    area: { type: 'string' },
    currentState: { type: 'string', description: 'concise, with file:line references' },
    requiredChanges: { type: 'array', items: { type: 'string' }, description: 'precise, ordered' },
    breakage: { type: 'array', items: { type: 'string' }, description: 'what breaks: tests, callers, the reader' },
    risks: { type: 'array', items: { type: 'string' }, description: 'edge cases / subtle failure modes' },
    openQuestions: { type: 'array', items: { type: 'string' } },
  },
}

const tasks = [
  {
    area: 'models + Bullet schema',
    files: 'app/models.py',
    focus: `Read app/models.py fully. Report the EXACT current Section/Anchor/VisualBlock/Frame/Note fields and how camelCase wire format works (the _Base alias_generator=to_camel, populate_by_name). Design the new Bullet model and the new Section shape per the target. Decide HOW the spoken-bullet transcript source is represented (e.g. an Anchor.transcript_text / source-kind field) so grounding can tell spoken-grounded from ungrounded. Note camelCase implications for nested bullets/blocks. List every field added/removed/changed.`,
  },
  {
    area: 'grounding tiers',
    files: 'app/grounding.py',
    focus: `Read app/grounding.py fully. Report the EXACT current rules (anchor_is_grounded, block_is_verifiable, check_note_grounding, GroundingReport). Specify the changes to (a) add the transcript-span tier (timestamp-only anchor WITH transcript source counts as grounded; timestamp-only WITHOUT source = ungrounded), (b) make grounding operate per-BULLET instead of per-section-anchor, (c) keep the genuinely-ungrounded tier. Propose the updated predicate(s) precisely and what GroundingReport should now count (e.g. visual vs spoken vs ungrounded bullets).`,
  },
  {
    area: 'structure pass: prompt + plan schema',
    files: 'app/structure.py',
    focus: `Read app/structure.py fully. Report the EXACT current plan JSON schema the prompt requests and what request_section_plan returns. Specify the NEW plan schema: sections with bullets, each bullet = {text, sourceKind(visual|spoken), blockRefs[], transcriptCiteSec or segment ref for spoken}, no detail. The model must do the semantic filter + block->bullet matching + cite (not invent) timestamps. List prompt-rule changes and what the model must NOT do (no block content, no invented timestamps). Keep the model seeing only compact block summaries.`,
  },
  {
    area: 'assembly: assemble_note',
    files: 'app/structure.py',
    focus: `Read app/structure.py's assemble_note fully. Report its EXACT current deterministic logic (block copy-verbatim, frames registry, per-section anchors, suggestedVerifyTimestampSec lookup, unknown-ref/dup/unresolved handling, AssemblyReport). Specify the NEW deterministic assembly for bullets: build Bullet objects, copy blocks verbatim into the right bullet, enforce one-block-at-most-one-bullet, snap spoken-bullet cite to nearest transcript segment.start deterministically, set visual-bullet timestamp from suggestedVerifyTimestampSec, demote unresolved -> ungrounded keeping text, drop semantically-filtered/unknown blocks with issues, keep the single frames registry. List the new AssemblyReport fields (placed/unplaced/filtered blocks, bullet tier counts).`,
  },
  {
    area: 'fixture re-expression',
    files: 'app/fixture.py',
    focus: `Read app/fixture.py fully. Report its EXACT current structure (3 sections with gist/detail/visualBlocks/anchors, INCLUDING the one deliberately ungrounded claim with empty frameRef that is the Step 2 demo). Specify how to re-express the fixture in the new bullets shape: which bullets are visual vs spoken vs ungrounded, and CRUCIALLY how to preserve the ungrounded-claim demo as an ungrounded BULLET. The fixture must stay a hand-authored, schema-valid Note (it is served for non-demo URLs and used by tests).`,
  },
  {
    area: 'tests + jobs + reader gap',
    files: 'tests/test_grounding.py, tests/test_jobs_smoke.py, tests/test_full_note.py, app/jobs.py, static/app.js',
    focus: `Read the three test files, app/jobs.py, and static/app.js. (1) List EVERY test assertion that reads section.detail, section.anchors, or section.visualBlocks (or fixture counts) and will BREAK under the new schema, file:line. (2) Confirm app/jobs.py demo-serve path (note_full.json) is unaffected by the schema change. (3) CRITICAL: static/app.js renders sec.detail/sec.anchors/sec.visualBlocks — after a DATA-ONLY 5A the served note has the new shape but app.js is unchanged until 5B, so the reader will render wrong/empty. Confirm exactly what app.js reads, and assess whether the intermediate (between 5A and 5B) broken-reader state is the expected staging tradeoff and whether any test drives the frontend (it should not). Propose the new/updated tests 5A needs (bullets contract, three-tier grounding, blocks-verbatim, one-block-one-bullet, snapped spoken timestamps, ungrounded survives).`,
  },
]

const findings = await parallel(tasks.map(t => () =>
  agent(
    `You are auditing ONE area of a FastAPI + Pydantic "video -> verifiable visual notes" codebase for an upcoming refactor (Step 5A). Read the file(s) and return a precise, line-referenced audit.\n\nAREA: ${t.area}\nFILES: ${t.files}\n\n${DESIGN}\n\nYOUR FOCUS:\n${t.focus}\n\nReturn ONLY the structured audit. Be concrete and exact (cite file:line). Do NOT write code or make edits — this is analysis for a plan.`,
    { label: `audit:${t.area}`, phase: 'Audit', schema: AUDIT, agentType: 'Explore' }
  )
))

return findings.filter(Boolean)
